package com.example.springtemplate.SSP.daos;

import com.example.springtemplate.SSP.models.Animal;
import com.example.springtemplate.SSP.repositories.AnimalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin(origins = "*")
public class AnimalDao {

    @Autowired
    AnimalRepository repository;
    @PostMapping("api/animals")
    public Animal createAnimal(@RequestBody Animal animal) {
        return repository.save(animal);
    }

    @GetMapping("/api/animals")
    public List<Animal> findAllAnimals() {
        return (List<Animal>) repository.findAll();
    }

    @GetMapping("/api/animals/{aid}")
    public Animal findAnimalById(
            @PathVariable("aid") Integer id) {
        return repository.findById(id).get();
    }

    @GetMapping("/api/animals/{aid}/name/{name}")
    public Animal updateAnimalName(
            @PathVariable("aid") Integer id,
            @PathVariable("name") String newAnimalName) {
        Animal animal = repository.findById(id).get();
        animal.setName(newAnimalName);
        return repository.save(animal);
    }

    @PutMapping("/api/animals/{aid}")
    public Animal updateAnimal(
            @PathVariable("aid") Integer id,
            @RequestBody Animal animalUpdates) {
        Animal animal = repository.findAnimalById(id);
        animal.setName(animalUpdates.getName());
        animal.setSex(animalUpdates.getSex());
        animal.setAnimalType(animalUpdates.getAnimalType());
        animal.setWeight(animalUpdates.getWeight());
        animal.setHeight(animalUpdates.getHeight());
        animal.setSpecies(animalUpdates.getSpecies());
        animal.setAge(animalUpdates.getAge());
        animal.setChildren(animalUpdates.getChildren());
        animal.setSpeed(animalUpdates.getSpeed());
        animal.setZoo(animalUpdates.getZoo());
        return repository.save(animal);
    }

    @DeleteMapping("/api/animals/{aid}")
    public void deleteAnimal(
            @PathVariable("aid") Integer id) {
        repository.deleteById(id);
    }
}

