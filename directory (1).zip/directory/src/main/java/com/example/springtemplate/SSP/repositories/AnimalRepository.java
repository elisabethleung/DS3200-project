package com.example.springtemplate.SSP.repositories;

import com.example.springtemplate.SSP.models.Animal;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface AnimalRepository
        extends CrudRepository<Animal, Integer> {
    @Query(value = "SELECT * FROM animals",
            nativeQuery = true)
    public List<Animal> findAllAnimals();
    @Query(value = "SELECT * FROM animals WHERE id=:aid",
            nativeQuery = true)
    public Animal findAnimalById(@Param("aid") Integer id);
}
