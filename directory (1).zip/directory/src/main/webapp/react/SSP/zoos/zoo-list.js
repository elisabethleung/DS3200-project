import service from "./zoo-service"

const {useEffect, useState} = React
const {Link,useHistory} = ReactRouterDOM

const ZooList = () => {
   const [zoos, setZoos] = useState([])
   const history = useHistory()
    useEffect(() => {
        service.findAllZoos()
            .then((zoos) => {
                setZoos(zoos)
            })
}, [] )
return (
<div>
    <h2>Zoos</h2>
                <button onClick={() => history.push("/zoos/new")}>
                    Add Zoo
                </button>
            <ul className="list-group">
                {
                    zoos.map((zoo) => {
                        return (
                            <li className="list-group-item">
                                <Link to={`/zoos/${zoo.id}`}>
                                    {zoo.name}
                                    </Link>
                            </li>
                        )
                    })
                }
            </ul>
</div>
)
}

export default ZooList