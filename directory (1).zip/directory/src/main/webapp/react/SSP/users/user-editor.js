import service from "./user-service"
const {useEffect, useState} = React
const {useParams, useHistory} = ReactRouterDOM

const UserEditor = () => {
    const [user, setUser] = useState([])
    const {uid} = useParams()
    const history = useHistory();
    useEffect(() => {
        if(uid !== "new") {
        findUserById(uid)
            }
     }, [])

    const findUserById = (uid) =>
        service.findUserById(uid)
              .then(user => setUser(user))

    const updateUserName = () => {
        service.updateUserName(user.id, user.name)
    }
    const deleteUser = (id) =>
        service.deleteUser(id)
            .then(() => history.goBack())
    const updateUser = (id, newUser) =>
        service.updateUser(id, newUser)
            .then(() => history.goBack())
    const createUser = (user) =>
        service.createUser(user)
            .then(() => history.goBack())

    return (
        <div>
            <h2>User Editor {uid}</h2>
            <label>ID</label>
            <input value={user.id} className="form-control"/>
            <label>First Name</label>
             <input
                 onChange={(e) => {
                     const newValue = e.target.value
                     setUser({...user, firstName: newValue})
                     }}
            value={user.firstName} className="form-control"/>
            <label>Last Name</label>
             <input
                 onChange={(e) => {
                     const newValue = e.target.value
                     setUser({...user, lastName: newValue})
                     }}
            value={user.lastName} className="form-control"/>
            <label>Username</label>
                         <input
                             onChange={(e) => {
                                 const newValue = e.target.value
                                 setUser({...user, username: newValue})
                                 }}
                        value={user.username} className="form-control"/>
            <label>Password</label>
                         <input
                             onChange={(e) => {
                                 const newValue = e.target.value
                                 setUser({...user, password: newValue})
                                 }}
                        value={user.password} className="form-control"/>
            <label>Email</label>
                         <input
                             onChange={(e) => {
                                 const newValue = e.target.value
                                 setUser({...user, email: newValue})
                                 }}
                        value={user.email} className="form-control"/>
            <label>Date of Birth</label>
                                     <input
                                         onChange={(e) => {
                                             const newValue = e.target.value
                                             setUser({...user, date_of_birth: newValue})
                                             }}
                                    value={user.date_of_birth} className="form-control"/>
            <label>Favorite Animal</label>
                                     <input
                                         onChange={(e) => {
                                             const newValue = e.target.value
                                             setUser({...user, favorite_animal: newValue})
                                             }}
                                    value={user.favorite_animal} className="form-control"/>
            <button
                onClick={() => deleteUser(user.id)}>
                Delete
            </button>
            <button onClick={() => updateUser(user.id, user)}>
                Save
            </button>
            <button
            onClick={() => createUser(user)}>
            Create
            </button>
            <button
                onClick={() => {
                history.goBack()}}>
                Cancel
            </button>
        </div>
        )
}

export default UserEditor;