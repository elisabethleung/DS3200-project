import service from "./user-service"

const {useEffect, useState} = React
const {Link,useHistory} = ReactRouterDOM

const UserList = () => {
   const [users, setUsers] = useState([])
   const history = useHistory()
    useEffect(() => {
        service.findAllUsers()
            .then((users) => {
                setUsers(users)
            })
}, [] )
return (
<div>
    <h2>Users</h2>
                <button onClick={() => history.push("/users/new")}>
                    Add User
                </button>
            <ul className="list-group">
                {
                    users.map((user) => {
                        return (
                            <li className="list-group-item">
                                <Link to={`/users/${user.id}`}>
                                    {user.lastName}, {user.firstName}
                                    </Link>
                            </li>
                        )
                    })
                }
            </ul>
</div>
)
}

export default UserList