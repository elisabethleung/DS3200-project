const USER_URL = 'http://localhost:8080/api/users'

const findAllUsers = () => {
    return fetch(USER_URL)
        .then((response) => {
            return response.json()
        })
}

const findUserById = (uid) => {
    return fetch(`${USER_URL}/${uid}`)
        .then((response) => {
            return response.json()
        })
}

const updateUserName = (uid, newUserName) => {
    return fetch(`${USER_URL}/${uid}/firstName/${newUserName}`)
        .then((response) => {
            return response.json()
        })
        }

export const deleteUser = (id) =>
    fetch(`${USER_URL}/${id}`, {
        method: "DELETE"
        })

export const updateUser = (id, user) =>
    fetch(`${USER_URL}/${id}`, {
        method: "PUT",
        body: JSON.stringify(user),
        headers: {'content-type': 'application/json'}
        })
        .then(response => response.json())

export const createUser = (user) =>
    fetch(USER_URL, {
        method: "POST",
        body: JSON.stringify(user),
        headers: {'content-type': 'application/json'}
    })
    .then(response => response.json())

export default {
    findAllUsers,
    findUserById,
    updateUserName,
    deleteUser,
    updateUser,
    createUser
    }