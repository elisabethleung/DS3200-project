import service from "./zoo-service"
const {useEffect, useState} = React
const {useParams, useHistory} = ReactRouterDOM

const ZooEditor = () => {
    const [zoo, setZoo] = useState([])
    const {zid} = useParams()
    const history = useHistory();
    useEffect(() => {
        if(zid !== "new") {
        findZooById(zid)
            }
     }, [])

    const findZooById = (zid) =>
        service.findZooById(zid)
              .then(zoo => setZoo(zoo))

    const updateZooName = () => {
        service.updateZooName(zoo.id, zoo.name)
    }
    const deleteZoo = (id) =>
        service.deleteZoo(id)
            .then(() => history.goBack())
    const updateZoo = (id, newZoo) =>
        service.updateZoo(id, newZoo)
            .then(() => history.goBack())
    const createZoo = (zoo) =>
        service.createZoo(zoo)
            .then(() => history.goBack())

    return (
        <div>
            <h2>Zoo Editor {zid}</h2>
            <label>ID</label>
            <input value={zoo.id} className="form-control"/>
            <label>Name</label>
             <input
                 onChange={(e) => {
                     const newValue = e.target.value
                     setZoo({...zoo, name: newValue})
                     }}
            value={zoo.name} className="form-control"/>
            <label>Location</label>
             <input
                 onChange={(e) => {
                     const newValue = e.target.value
                     setZoo({...zoo, location: newValue})
                     }}
            value={zoo.location} className="form-control"/>
            <label>Average Guests</label>
                         <input
                             onChange={(e) => {
                                 const newValue = e.target.value
                                 setZoo({...zoo, averageGuests: newValue})
                                 }}
                        value={zoo.averageGuests} className="form-control"/>
            <label>Employees</label>
                         <input
                             onChange={(e) => {
                                 const newValue = e.target.value
                                 setZoo({...zoo, employees: newValue})
                                 }}
                        value={zoo.employees} className="form-control"/>
            <label>Size</label>
                         <input
                             onChange={(e) => {
                                 const newValue = e.target.value
                                 setZoo({...zoo, size: newValue})
                                 }}
                        value={zoo.size} className="form-control"/>
            <button
                onClick={() => deleteZoo(zoo.id)}>
                Delete
            </button>
            <button onClick={() => updateZoo(zoo.id, zoo)}>
                Save
            </button>
            <button
            onClick={() => createZoo(zoo)}>
            Create
            </button>
            <button
                onClick={() => {
                history.goBack()}}>
                Cancel
            </button>
        </div>
        )
}

export default ZooEditor;