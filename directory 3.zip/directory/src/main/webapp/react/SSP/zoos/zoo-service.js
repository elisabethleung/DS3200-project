const ZOO_URL = 'http://localhost:8080/api/zoos'

const findAllZoos = () => {
    return fetch(ZOO_URL)
        .then((response) => {
            return response.json()
        })
}

const findZooById = (zid) => {
    return fetch(`${ZOO_URL}/${zid}`)
        .then((response) => {
            return response.json()
        })
}

const updateZooName = (zid, newZooName) => {
    return fetch(`${ZOO_URL}/${zid}/name/${newZooName}`)
        .then((response) => {
            return response.json()
        })
        }

export const deleteZoo = (id) =>
    fetch(`${ZOO_URL}/${id}`, {
        method: "DELETE"
        })

export const updateZoo = (id, zoo) =>
    fetch(`${ZOO_URL}/${id}`, {
        method: "PUT",
        body: JSON.stringify(zoo),
        headers: {'content-type': 'application/json'}
        })
        .then(response => response.json())

export const createZoo = (zoo) =>
    fetch(ZOO_URL, {
        method: "POST",
        body: JSON.stringify(zoo),
        headers: {'content-type': 'application/json'}
    })
    .then(response => response.json())

export default {
    findAllZoos,
    findZooById,
    updateZooName,
    deleteZoo,
    updateZoo,
    createZoo
    }