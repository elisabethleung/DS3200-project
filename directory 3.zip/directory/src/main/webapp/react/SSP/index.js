import ZooList from "./zoos/zoo-list";
import ZooEditor from "./zoos/zoo-editor";
import AnimalList from "./animals/animal-list";
import AnimalEditor from "./animals/animal-editor";
import UserList from "./users/user-list";
import UserEditor from "./users/user-editor";

const {HashRouter, Link, Route} = window.ReactRouterDOM;
 
const App = () => {
    return (
        <div className="container-fluid">
        <h1>Global Species Database</h1>
            <HashRouter>
                <Route path={["/zoos", "/"]} exact={true}>
                <ZooList/>
                </Route>
                <Route path="/zoos/:zid" exact={true}>
                    <ZooEditor/>
                </Route>
                <Route path={["/animals", "/"]} exact={true}>
                <AnimalList/>
                </Route>
                <Route path="/animals/:aid" exact={true}>
                    <AnimalEditor/>
                </Route>
                <Route path={["/users", "/"]} exact={true}>
                <UserList/>
                </Route>
                <Route path="/users/:uid" exact={true}>
                    <UserEditor/>
                </Route>
            </HashRouter>
        </div>
    );
}

export default App;
