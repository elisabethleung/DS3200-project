const ANIMAL_URL = 'http://localhost:8080/api/animals'

const findAllAnimals = () => {
    return fetch(ANIMAL_URL)
        .then((response) => {
            return response.json()
        })
}

const findAnimalById = (aid) => {
    return fetch(`${ANIMAL_URL}/${aid}`)
        .then((response) => {
            return response.json()
        })
}

export const deleteAnimal = (id) =>
    fetch(`${ANIMAL_URL}/${id}`, {
        method: "DELETE"
        })


 const updateAnimalName = (aid, newAnimalName) => {
    return fetch(`${ANIMAL_URL}/${aid}/name/${newAnimalName}`)
      .then((response) => {
            return response.json()
        })
        }


export const updateAnimal = (id, animal) =>
    fetch(`${ANIMAL_URL}/${id}`, {
        method: "PUT",
        body: JSON.stringify(animal),
        headers: {'content-type': 'application/json'}
        })
        .then(response => response.json())

export const createAnimal = (animal) =>
    fetch(ANIMAL_URL, {
        method: "POST",
        body: JSON.stringify(animal),
        headers: {'content-type': 'application/json'}
    })
    .then(response => response.json())

export default {
    findAllAnimals,
    findAnimalById,
    updateAnimalName,
    deleteAnimal,
    updateAnimal,
    createAnimal
    }