import service from "./animal-service"

const {useEffect, useState} = React
const {Link,useHistory} = ReactRouterDOM

const AnimalList = () => {
   const [animals, setAnimals] = useState([])
   const history = useHistory()
    useEffect(() => {
        service.findAllAnimals()
            .then((animals) => {
                setAnimals(animals)
            })
}, [] )
return (
<div>
    <h2>Animals</h2>
                <button onClick={() => history.push("/animals/new")}>
                    Add Animal
                </button>
            <ul className="list-group">
                {
                    animals.map((animal) => {
                        return (
                            <li className="list-group-item">
                                <Link to={`/animals/${animal.id}`}>
                                    {animal.name}
                                    </Link>
                            </li>
                        )
                    })
                }
            </ul>
</div>
)
}

export default AnimalList