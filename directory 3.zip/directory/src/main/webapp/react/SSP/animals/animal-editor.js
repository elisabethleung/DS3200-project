import service from "./animal-service"
const {useEffect, useState} = React
const {Link, useParams, useHistory} = ReactRouterDOM

const AnimalEditor = () => {
    const [animal, setAnimal] = useState([])
    const {aid} = useParams()
    const history = useHistory();
    useEffect(() => {
        if(aid !== "new") {
        findAnimalById(aid)
            }
     }, [])

    const findAnimalById = (aid) =>
        service.findAnimalById(aid)
              .then(animal => setAnimal(animal))

    const updateAnimalName = () => {
        service.updateAnimalName(animal.id, animal.name)
    }
    const deleteAnimal = (id) =>
        service.deleteAnimal(id)
            .then(() => history.goBack())

    const updateAnimal = (id, newAnimal) =>
        service.updateAnimal(id, newAnimal)
            .then(() => history.goBack())

    const createAnimal = (animal) =>
        service.createAnimal(animal)
            .then(() => history.goBack())

    return (
        <div>
            <h2>Animal Editor {aid}</h2>
            <label>ID</label>
            <input value={animal.id} className="form-control"/>
            <label>Name</label>
             <input
                 onChange={(e) => {
                     const newValue = e.target.value
                     setAnimal({...animal, name: newValue})
                     }}
            value={animal.name} className="form-control"/>
            <label>Sex</label>
             <input
                 onChange={(e) => {
                     const newValue = e.target.value
                     setAnimal({...animal, sex: newValue})
                     }}
            value={animal.sex} className="form-control"/>
           <label>Animal Type</label>
                         <input
                 onChange={(e) => {
                     const newValue = e.target.value
                     setAnimal({...animal, animalType: newValue})
                     }}
            value={animal.animalType} className="form-control"/>
            <label>Weight</label>
                         <input
                             onChange={(e) => {
                                 const newValue = e.target.value
                                 setAnimal({...animal, weight: newValue})
                                 }}
                        value={animal.weight} className="form-control"/>
            <label>Height</label>
                         <input
                             onChange={(e) => {
                                 const newValue = e.target.value
                                 setAnimal({...animal, height: newValue})
                                 }}
                        value={animal.height} className="form-control"/>
            <label>Species</label>
                           <input
                               onChange={(e) => {
                                   const newValue = e.target.value
                                   setAnimal({...animal, species: newValue})
                                   }}
                          value={animal.species} className="form-control"/>
          <label>Age</label>
                         <input
                             onChange={(e) => {
                                 const newValue = e.target.value
                                 setAnimal({...animal, age: newValue})
                                 }}
                        value={animal.age} className="form-control"/>
          <label>Children</label>
                         <input
                             onChange={(e) => {
                                 const newValue = e.target.value
                                 setAnimal({...animal, children: newValue})
                                 }}
                        value={animal.children} className="form-control"/>
          <label>Speed</label>
                         <input
                             onChange={(e) => {
                                 const newValue = e.target.value
                                 setAnimal({...animal, speed: newValue})
                                 }}
                        value={animal.speed} className="form-control"/>
          <label><Link to={`/zoos/${animal.zoo}`}>
            Zoo: {animal.zoo}
            </Link></label>
                                   <input
                                       onChange={(e) => {
                                           const newValue = e.target.value
                                           setAnimal({...animal, zoo: newValue})
                                           }}
                                  value={animal.zoo} className="form-control"/>

            <button
                onClick={() => deleteAnimal(animal.id)}>
                Delete
            </button>
            <button onClick={() => createAnimal(animal)}>
                Save
            </button>
            <button
            onClick={() => createAnimal(animal)}>
            Create
            </button>
            <button
                onClick={() => {
                history.goBack()}}>
                Cancel
            </button>
        </div>
        )
}

export default AnimalEditor;