const GnrxFormInput = () => {
    return(
        <>
            Form Input
        </>
    )
}

export default GnrxFormInput;