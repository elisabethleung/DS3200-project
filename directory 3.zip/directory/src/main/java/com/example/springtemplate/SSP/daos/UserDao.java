package com.example.springtemplate.SSP.daos;

import com.example.springtemplate.SSP.models.User;
import com.example.springtemplate.SSP.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
public class UserDao {

    @Autowired
    UserRepository repository;
    @PostMapping("api/users")
    public User createUser(@RequestBody User user) {
        return repository.save(user);
    }

    @GetMapping("/api/users")
    public List<User> findAllUsers() {
        return (List<User>) repository.findAll();
    }

    @GetMapping("/api/users/{uid}")
    public User findUserById(
            @PathVariable("uid") Integer id) {
        return repository.findById(id).get();
    }

    @GetMapping("/api/users/{uid}/firstName/{firstName}")
    public User updateUserName(
        @PathVariable("uid") Integer id,
        @PathVariable("firstName") String newUserName) {
    User user = repository.findById(id).get();
    user.setFirstName(newUserName);
    return repository.save(user);
        }

    @PutMapping("/api/users/{uid}")
    public User updateUser(
            @PathVariable("uid") Integer id,
            @RequestBody User userUpdates) {
         User user= repository.findUserById(id);
        user.setFirstName(userUpdates.getFirstName());
        user.setLastName(userUpdates.getLastName());
        user.setUsername(userUpdates.getUsername());
        user.setPassword(userUpdates.getPassword());
        user.setEmail(userUpdates.getEmail());
        user.setDateOfBirth(userUpdates.getDateOfBirth());
        user.setFavoriteAnimal(userUpdates.getFavoriteAnimal());
        return repository.save(user);
    }

        @DeleteMapping("/api/users/{uid}")
    public void deleteUser(
        @PathVariable("uid") Integer id) {
        repository.deleteById(id);
    }
}
