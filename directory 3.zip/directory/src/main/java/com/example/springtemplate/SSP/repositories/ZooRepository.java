package com.example.springtemplate.SSP.repositories;

import com.example.springtemplate.SSP.models.Zoo;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ZooRepository
    extends CrudRepository<Zoo, Integer> {
    @Query(value = "SELECT * FROM zoos",
    nativeQuery = true)
    public List<Zoo> findAllZoos();
    @Query(value = "SELECT * FROM zoos WHERE id=:zid",
    nativeQuery = true)
    public Zoo findZooById(@Param("zid") Integer id);

}
