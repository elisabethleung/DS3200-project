package com.example.springtemplate.SSP.daos;

import com.example.springtemplate.SSP.models.Zoo;
import com.example.springtemplate.SSP.repositories.ZooRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@CrossOrigin(origins = "*")
public class ZooDao {

    @Autowired
    ZooRepository repository;
    @PostMapping("api/zoos")
    public Zoo createZoo(@RequestBody Zoo zoo) {
        return repository.save(zoo);
    }

    @GetMapping("/api/zoos")
    public List<Zoo> findAllZoos() {
        return (List<Zoo>) repository.findAll();
    }

    @GetMapping("/api/zoos/{zid}")
    public Zoo findZooById(
            @PathVariable("zid") Integer id) {
        return repository.findById(id).get();
    }

    @GetMapping("/api/zoos/{zid}/name/{name}")
    public Zoo updateZooName(
        @PathVariable("zid") Integer id,
        @PathVariable("name") String newZooName) {
    Zoo zoo = repository.findById(id).get();
    zoo.setName(newZooName);
    return repository.save(zoo);
        }
        
    @PutMapping("/api/zoos/{zid}")
    public Zoo updateZoo(
            @PathVariable("zid") Integer id,
            @RequestBody Zoo zooUpdates) {
         Zoo zoo= repository.findZooById(id);
        zoo.setName(zooUpdates.getName());
        zoo.setLocation(zooUpdates.getLocation());
        zoo.setAverageGuests(zooUpdates.getAverageGuests());
        zoo.setEmployees(zooUpdates.getEmployees());
        zoo.setSize(zooUpdates.getSize());
        return repository.save(zoo);
    }

        @DeleteMapping("/api/zoos/{zid}")
    public void deleteZoo(
        @PathVariable("zid") Integer id) {
        repository.deleteById(id);
    }
}
